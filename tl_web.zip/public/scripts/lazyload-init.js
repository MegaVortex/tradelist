document.addEventListener("DOMContentLoaded", function() {
  new LazyLoad({
    elements_selector: ".lazy"
  });
});