const fs = require("fs");
const path = require("path");

module.exports = function () {
  const dataDir = path.join(__dirname, "data");
  const files = fs.readdirSync(dataDir).filter(name => name.endsWith(".json"));

  return files.map(filename => {
    const filePath = path.join(dataDir, filename);
    const show = JSON.parse(fs.readFileSync(filePath, "utf-8"));
    const slug = filename.replace(/\.json$/, "");

    return {
      // This must be an object with .data and .render
      data: {
        layout: "templates/show.njk",
        permalink: `/shows/${slug}/index.html`,
        show, // 🔥 this makes `show` available in show.njk
      },
      render: function () {
        // Eleventy requires render to return a string or buffer.
        return ""; // layout will handle it, no need to render here
      },
    };
  });
};
